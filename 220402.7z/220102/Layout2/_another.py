from PyQt5.QtWidgets import QMainWindow

class AnotherWindow(QMainWindow):
    def __init__(self):
      super().__init__() ; self.initUI()
      
    from initUI21 import initUI  
    from def21 import chkb_i,chkb_i2,chkb_s,ch_da,wi2,al1