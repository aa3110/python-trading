import sys
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout)

# class Wind(QMainWindow):  # this what i need
class Wind(QWidget):   
    def __init__(self):      #__init__ method
        super(Wind, self).__init__()
        self.setWindowTitle("first-window")
        self.resize(500, 400)
        self.scaleFactor = 0.0

        self.widget = QWidget(self)
        self.widget.setStyleSheet(""".QWidget {background-color: rgb(0, 200, 100);}""")
     
        # self.widget.setStyleSheet("color: blue;"
        #                 "background-color: yellow;"
        #                 "selection-color: red;"
        #                 "selection-background-color: blue;");      
     
      
        layout = QVBoxLayout(self)        
        layout.addWidget(self.widget)

if __name__ == '__main__':

    app = QApplication(sys.argv)
    imageViewer = Wind() ; imageViewer.show()
    sys.exit(app.exec_())