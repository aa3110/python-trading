import sys
from PyQt5 import QtWidgets

color_red = "color_red"
color_blue = "color_blue"

backcolor_skyblue = "bcolor_skyblue"
backcolor_lightgreen = "bcolor_lightgreen"

class CssSample(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Css Stylesheet")

        self.label_1 = QtWidgets.QLabel("Sample 1 Label")
        self.label_1.setFixedSize(200,50)
        self.label_1.setProperty("color",color_red )
        self.label_1.setProperty("backcolor",backcolor_skyblue)
        self.label_1.setStyleSheet(my_stylesheet())
      
        self.label_2 = QtWidgets.QLabel("Sample 2 Label")
        self.label_2.setFixedSize(200, 50)
        self.label_2.setProperty("color", color_blue)
        self.label_2.setProperty("backcolor",backcolor_lightgreen)
        self.label_2.setStyleSheet(my_stylesheet())

        self.vbox = QtWidgets.QVBoxLayout()
        self.vbox.addWidget(self.label_1)
        self.vbox.addWidget(self.label_2)
        self.setLayout(self.vbox)

def my_stylesheet():
    
    return """
    QLabel[color = "color_red"]
    { color : red;font-family: Trebuchet MS; font-style: normal; font-size:12pt; font-weight:700; }
    
    QLabel[color = "color_blue"]
    { color : blue;font-family: Trebuchet MS; font-style: normal; font-size:12pt; font-weight:700;}
    
    QLabel[backcolor = "bcolor_skyblue"]
    { background-color : skyblue}
    
    QLabel[backcolor = "bcolor_lightgreen"]
    { background-color : lightgreen}
    
    QLabel{ background-color: @mycolor;}
    
"""

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    mainwindow = CssSample() ; mainwindow.show()
    sys.exit(app.exec_())