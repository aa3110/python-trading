import sys
import matplotlib
import pandas as pd
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure
matplotlib.use("Qt5Agg")
from PyQt5.QtWidgets import QWidget,QVBoxLayout,QApplication,QMainWindow

class MplCanvas(FigureCanvasQTAgg):
  def __init__(self, parent=None, width=5, height=4, dpi=100):
    fig = Figure(figsize=(width, height), dpi=dpi)
    self.axes = fig.add_subplot(111)
    super().__init__(fig)

    
class MainWindow(QMainWindow):
  def __init__(self):
    super().__init__()
    
    sc = MplCanvas(self, width=5, height=4, dpi=100)
       
    df = pd.DataFrame(
    [[0, 10], [5, 15], [2, 20], [15, 25], [4, 10],], columns=
    ["A", "B"]
    )
  
    df.plot(ax=sc.axes)
  
    
    toolbar = NavigationToolbar(sc, self)
    
    layout = QVBoxLayout()
    layout.addWidget(toolbar)
    layout.addWidget(sc)
    
    # Create a placeholder widget to hold our toolbar and canvas.
    widget = QWidget()
    widget.setLayout(layout)
    self.setCentralWidget(widget)
   
app = QApplication(sys.argv)
w = MainWindow(); w.show()
app.exec_()


## import figure to replace 21..30 