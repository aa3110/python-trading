para=(7,1.5)
nb=1.4
sval=(7,14,20)
val1=7
####
stock='SIE'
stock2=stock+str(para[0])
start='2020-01-01'