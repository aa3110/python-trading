from constant_serie import *
from pathlib import Path
import os

plr=(230,500)  # plot range


dir_p=  os.path.join(Path(os.path.abspath(os.path.dirname(__file__))+'\\').parent.parent, "inout\\picture\\serie\\")

# dir_p="D:\\picture\\serie\\"


plot_fig=1 # 1=yes
################### plots #################################