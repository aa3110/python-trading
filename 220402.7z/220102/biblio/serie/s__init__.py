import path_def.pat1

from s_serie import serie
from s_run_serie import run_serie