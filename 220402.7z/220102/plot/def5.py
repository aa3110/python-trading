def prg_plot(self):
  import script.prg_plot
  return self.statusBar().showMessage('done: plot')