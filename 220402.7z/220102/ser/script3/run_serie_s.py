import path_def.pat1
from s_run_serie import run_serie

run_serie('SIE',7,df=None)