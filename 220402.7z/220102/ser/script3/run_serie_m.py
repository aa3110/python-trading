import path_def.pat1
from s_run_serie import run_serie
from constant_serie import sval

for val1 in sval:
  run_serie('SIE',val1,df=None)