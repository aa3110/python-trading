def run_serie_s(self):  
  import script3.run_serie_s  
  return self.statusBar().showMessage('done: run_serie_s')
  
def run_serie_m(self):
  import script3.run_serie_m
  return self.statusBar().showMessage('done: run_serie_m')