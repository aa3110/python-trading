def sl_serie(self):
  import script4.slideshow_serie_3
  return self.statusBar().showMessage('done: slideshow_serie')
  
def sl_bus(self):
  import script4.slideshow_bus_3
  return self.statusBar().showMessage('done: slideshow_bus')