import io
import matplotlib
import matplotlib.pyplot as plt
import numpy as np

import base64
from PIL import Image
from io import BytesIO


t = np.arange(0.0, 2.0, 0.01)
s = 1 + np.sin(2 * np.pi * t)
  
fig, ax = plt.subplots()
ax.plot(t, s)
  
ax.set(xlabel='qq'+'(s)', ylabel='voltage (mV)',title='About as simple as it gets, folks')
# ax.grid()
 
b1 = io.BytesIO()
plt.savefig(b1, format='png')
# b64 = base64.b64encode(b1.getvalue())


b1.seek(0)

plt.close()
imb=b1.getvalue()
plt.imshow(imb)
# d1('time')

# b2 = io.BytesIO()
# plt.savefig(b2, format='png')
# plt.close()

# plt.show(b1)
# plt.show(b2)


# output= io.BytesIO()
# plt.savefig(output, format="PNG")
# im_bytes = output.getvalue()

# plt.show(imb)

b64=imb
img = Image.open(io.BytesIO(base64.b64decode(b64)))
plt.imshow(img)
# plt.show()