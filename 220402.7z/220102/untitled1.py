# Importing the StringIO module.
from io import StringIO 
 
 
# The arbitrary string.
string ='Hello and welcome to GeeksForGeeks.'
 
# Using the StringIO method to
# set as file object.
file = StringIO(string)
 
# Retrieve the entire content of the file.
print(file.getvalue())