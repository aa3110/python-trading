import sys
from PyQt5.QtWidgets import QApplication, QMainWindow,QTabWidget,QHBoxLayout
from PyQt5.QtWidgets import QWidget, QLabel,QComboBox,QPushButton
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import QRect


class MW(QMainWindow):
    def __init__(self):
      super().__init__()
      self.resize(1600, 900) # self.setGeometry(0, 0, 1600, 800) 
      
      self.tabs = QTabWidget()     
      self.tabs.setMovable(True)
            
      self.tab1,self.tab2,self.tab3,self.tab4 = QWidget(),QWidget(),QWidget(),QWidget()
      self.tabs.addTab(self.tab1,"Calc");self.tabs.addTab(self.tab2,"Chart");self.tabs.addTab(self.tab3,"depot");self.tabs.addTab(self.tab4,"signal")
            
      self.setCentralWidget(self.tabs)
             
      self.lab1 = QLabel(self.tab2)
      self.lab1.setGeometry(0, 50, 1200, 800) # self.lab1.setFixedSize(1200, 800)
      self.lab1.setPixmap(QPixmap("b1.png"))
      self.lab1.setScaledContents(True)
               
      self.btn_chkb_s = QPushButton(self.tab2)
      self.btn_chkb_s.move(0,20)
      self.btn_chkb_s.setText("chkbox_st")
      self.btn_chkb_s.clicked.connect(self.chkb_s)
      
      self.btn_chkb_i = QPushButton(self.tab2)
      self.btn_chkb_i.move(80, 20)
      self.btn_chkb_i.setText("chkbox_ind")
      self.btn_chkb_i.clicked.connect(self.chkb_i)
   
    def chkb_i(self):
      import chkbox_ind
      return self.statusBar().showMessage('done: chkbox_ind')
      
    def chkb_s(self):
      import chkbox_st
      return self.statusBar().showMessage('done: chkbox_st')
       
      
if __name__ == "__main__": 
    app = QApplication(sys.argv)
    win = MW() ; win.show()
    sys.exit(app.exec_())