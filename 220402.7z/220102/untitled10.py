import random
import io
from PIL import Image, ImageTk 

import matplotlib.pyplot as plt
from PIL import Image
 
w=600;h=600
 
plt.hist([random.random() for _ in range(100)])

b1 = io.BytesIO();plt.savefig(b1)
b1.seek(0)
# Image.open(b1).show()
plt.close()

# i1=Image.open(b1) ; i1 = i1.resize((w,h), Image.ANTIALIAS)

####

import tkinter as tk
from tkinter import Tk, Label ,Checkbutton
from PIL import Image, ImageTk
from pathlib import Path 
from itertools import cycle  
import os 

# dir_p =  os.path.join(Path(os.path.abspath(os.path.dirname(__file__))+'\\').parent.parent, "inout\\picture\\bus")
w,h,delay=800,800,2000

app=tk.Tk() ; app.geometry(str(w)+"x"+str(h))
lab=Label() ; lab.pack()

def Phot(p1="a1.png"):
  i1=Image.open(p1) ; i1 = i1.resize((w,h), Image.ANTIALIAS)
  pic=ImageTk.PhotoImage(i1)
  lab.config(image=pic)  
  return pic

def show_slides():
    lab.config(image=pic)
    app.after(delay, show_slides)

# pic=cycle(map(lambda x :Phot(x) ,list(Path(dir_p).glob("*.png"))))
pic=Phot(b1)
show_slides()

app.mainloop()