def plot_bus(self):
  import script2.bus_plot
  return self.statusBar().showMessage('done: bus_plot')