import base64
from cv2 import cv2
import io
import numpy as np
import imageio
#
import matplotlib
import matplotlib.pyplot as plt
from PIL import Image
from io import BytesIO


def loadImageFromImageBytes(imageBytes):
    npimg = np.fromstring(imageBytes.read(), np.uint8)
    return cv2.cvtColor(cv2.imdecode(npimg, cv2.IMREAD_UNCHANGED), cv2.COLOR_RGB2BGR)

def loadImageFromFlaskFileStorageObject(fileStorageObject):
    npimg = np.fromstring(fileStorageObject.read(), np.uint8)
    return cv2.cvtColor(cv2.imdecode(npimg, cv2.IMREAD_UNCHANGED), cv2.COLOR_RGB2BGR)

def encodeImageUsingBase64(image, fileType='.png'):
    assert "." in  fileType, "File type must include dot(.)"
    return base64.b64encode(cv2.imencode(fileType, image)[1].tostring()).decode('UTF-8')

def encodeImageBytesUsingBase64(imageBytes, fileType='.png'):
    assert "." in  fileType, "File type must include dot(.)"
    return base64.b64encode(imageBytes.read()).decode('UTF-8')

# import matplotlib as mpl; mpl.use("Agg")
# import matplotlib.pyplot as plt

def pltSaveFigToBytes(plt, imageType="png"):
    assert not "." in imageType, "Image type should not contain dot(.)"
    imageBytes = io.BytesIO()
    plt.savefig(imageBytes, format=imageType)
    imageBytes.seek(0)
    return imageBytes

def createGifWithBase64Encoding(frames, duration=1):
    imageBytes = io.BytesIO()
    imageio.mimwrite(imageBytes, frames, format="GIF", duration = duration)
    imageBytes.seek(0)
    return base64.b64encode(imageBytes.read()).decode("UTF-8")
  
  
t = np.arange(0.0, 2.0, 0.01)
s = 1 + np.sin(2 * np.pi * t)
  
fig, ax = plt.subplots()
ax.plot(t, s)
  
ax.set(xlabel='qq'+'(s)', ylabel='voltage (mV)',title='About as simple as it gets, folks')

  