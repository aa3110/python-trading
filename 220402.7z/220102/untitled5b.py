import io
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# t = np.arange(0.0, 2.0, 0.01)
# s = 1 + np.sin(2 * np.pi * t)

d = {'col1': [1, 2], 'col2': [3, 4]}
df = pd.DataFrame(data=d)

t=df['col1']
s=df['col2']


w1='time'
  
fig, ax = plt.subplots()
ax.plot(t, s)
  
ax.set(xlabel=w1+'(s)', ylabel='voltage (mV)',title='About as simple as it gets, folks')
  # ax.grid()
  
b1 = io.BytesIO();plt.savefig(b1, format='png')
b1.seek(0)
plt.close()  

# b1 = io.BytesIO()
# plt.savefig(b1, format='png')
# plt.close(b1)
 
# d1('time')

# b2 = io.BytesIO()
# plt.savefig(b2, format='png')
# plt.close()

plt.show(b1)
# plt.show(b2)

